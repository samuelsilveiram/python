from unittest import TestCase
import json
import os

from werkzeug.wrappers import BaseResponse
from werkzeug.test import Client

from app import ApiApp, SQLiteApp
from rest_api_framework.controllers import WSGIDispatcher


class TestPagination(TestCase):
    def test_base_pagination(self):
        client = Client(WSGIDispatcher([ApiApp]),
                        response_wrapper=BaseResponse)
        resp = client.get("/address/")

        self.assertEqual(len(json.loads(resp.data)["object_list"]), 20)

    def test_base_pagination_count(self):
        client = Client(WSGIDispatcher([ApiApp]),
                        response_wrapper=BaseResponse)
        resp = client.get("/address/?count=3")
        self.assertEqual(len(json.loads(resp.data)["object_list"]), 3)

    def test_max_pagination_count(self):
        client = Client(WSGIDispatcher([ApiApp]),
                        response_wrapper=BaseResponse)
        resp = client.get("/address/?offset=82")
        self.assertEqual(json.loads(resp.data)["meta"]['next'], "null")
        self.assertEqual(len(json.loads(resp.data)["object_list"]), 19)

    def test_base_pagination_count_overflow(self):
        client = Client(WSGIDispatcher([ApiApp]),
                        response_wrapper=BaseResponse)
        resp = client.get("/address/?count=200")
        self.assertEqual(len(json.loads(resp.data)["object_list"]), 20)

    def test_base_pagination_offset(self):
        client = Client(WSGIDispatcher([ApiApp]),
                        response_wrapper=BaseResponse)
        resp = client.get("/address/?offset=2")
        self.assertEqual(
            json.loads(resp.data)["object_list"][0]['ressource_uri'],
            "/address/2/")


class TestSQlitePagination(TestCase):
    def test_base_pagination(self):
        client = Client(WSGIDispatcher([SQLiteApp]),
                        response_wrapper=BaseResponse)

        for i in range(100):
            client.post("/address/",
                        data=json.dumps({"name": "bob", "age": 34}))

        resp = client.get("/address/")

        self.assertEqual(len(json.loads(resp.data)["object_list"]), 20)

    def test_base_pagination_offset(self):
        client = Client(WSGIDispatcher([SQLiteApp]),
                        response_wrapper=BaseResponse)

        for i in range(100):
            client.post("/address/",
                        data=json.dumps({"name": "bob", "age": 34}))

        resp = client.get("/address/?offset=2")

        self.assertEqual(json.loads(resp.data)["object_list"][0]['id'], 2)


    def test_base_pagination_count(self):
        client = Client(WSGIDispatcher([SQLiteApp]),
                        response_wrapper=BaseResponse)

        for i in range(100):
            client.post("/address/",
                        data=json.dumps({"name": "bob", "age": 34}))

        resp = client.get("/address/?count=2")

        self.assertEqual(len(json.loads(resp.data)), 2)


    def test_base_pagination_count_offset(self):
        client = Client(WSGIDispatcher([SQLiteApp]),
                        response_wrapper=BaseResponse)

        for i in range(100):
            client.post("/address/",
                        data=json.dumps({"name": "bob", "age": 34}))

        resp = client.get("/address/?count=2&offset=4")

        self.assertEqual(len(json.loads(resp.data)), 2)
        self.assertEqual(json.loads(resp.data)["object_list"][0]['id'], 4)
