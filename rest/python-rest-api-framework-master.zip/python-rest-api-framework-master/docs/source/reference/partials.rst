Partials
========

.. automodule:: rest_api_framework.partials
   :members:
   :member-order: bysource
