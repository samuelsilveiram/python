DataStores
=========

.. autoclass:: rest_api_framework.datastore.base.DataStore
   :members:
   :member-order: bysource

.. autoclass:: rest_api_framework.datastore.simple.PythonListDataStore
   :members:
   :member-order: bysource
   :show-inheritance:

.. autoclass:: rest_api_framework.datastore.sql.SQLiteDataStore
   :members:
   :member-order: bysource
   :show-inheritance:
