Authentication
==============

.. autoclass:: rest_api_framework.authentication.Authentication
   :members:
   :member-order: bysource

.. autoclass:: rest_api_framework.authentication.ApiKeyAuthentication
   :members:
   :member-order: bysource

.. autoclass:: rest_api_framework.authentication.BasicAuthentication
   :members:
   :member-order: bysource
