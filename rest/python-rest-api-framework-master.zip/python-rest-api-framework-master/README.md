python-rest-api-framework
=========================

Python REST API framework is a set of utilities based on werkzeug to easily build Restful API.
It keep a clean codebase and is easy to configure and extends.

read the full documentation on read the doc: http://python-rest-framework.readthedocs.org/en/latest/index.html


[![Build Status](http://jenkins.gabory.fr/job/praf/badge/icon)](http://jenkins.gabory.fr/job/praf/)